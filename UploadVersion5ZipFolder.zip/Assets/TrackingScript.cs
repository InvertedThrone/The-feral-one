using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackingScript : MonoBehaviour
{
    public GameObject targetfollowing;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        targetfollowing = GameObject.FindGameObjectWithTag("Player");

            gameObject.transform.position = targetfollowing.transform.position;
    } 
}
