using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class selfdestructscript : MonoBehaviour
{

    public float destroytime = 1f;
    private float timer = 0;




    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (timer < destroytime)
        {
            timer += Time.deltaTime;
        }
        else
        {
            Debug.Log("Too far");
            Destroy(gameObject);
        }
         void OnTriggerEnter2D(Collider2D hitInfo)
        {
            if (hitInfo.tag != "Enemy")
            {


                Destroy(gameObject);
            }
        }
    } 
}


