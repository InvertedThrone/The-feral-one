using JetBrains.Annotations;
using System.Runtime.CompilerServices;
using UnityEngine;

public class healthscript : MonoBehaviour
{
    public int health = 50;
    public int maxhealth = 50;
    public int posture = 25;
    public int maxposture = 25;
    public GameObject stunstars;
    public Transform stunlocation;
    public bool stunned = false;
    public float stuntimer = 0f;
    public bool idle = true;
    Transform attacker;
    OffenseScript damagetracker;

    [SerializeField] FloatingHealthBar healthBar;

    private void Start()
    {
       healthBar = GetComponentInChildren<FloatingHealthBar>();
        healthBar.HealthBarUpdate(health, maxhealth);
    }
    public void Update()
    {

        if (stunned == true)
        {
            stuntimer += Time.deltaTime;
        }

        if (stuntimer >= 3.0f)
        {
            stunned = false;
            stuntimer = 0f;
        }

    }

    public void takedamage(int damage)
    {
        health -= damage;

        if (health <= 0)
        {
            Die();
            Debug.Log("Died");
        }
        healthBar.HealthBarUpdate(health, maxhealth);
    }
    public void takeposture(int posturedamage)
    {
        posture -= posturedamage;
        if (posture <= 0 && stunned == false)
        {
            nowstunned();
        }
    }
    void Die()
    {
        Destroy(gameObject);
    }
    void nowstunned()
    {
        stunned = true;

        Instantiate(stunstars, stunlocation.position, stunlocation.rotation);
    }

    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (hitInfo.gameObject.tag == "Player")
        {
            Debug.Log("Idle off");
            idle = false;
        }

     void OnTriggerExit2D(Collider2D collision)
    {
            if (collision.gameObject.tag == "player")
            {
                idle = true;
                Debug.Log("Idle On");
            }
    }
}
}
