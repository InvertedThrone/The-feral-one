using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static float humanhealth = 1f;
    public static float maxhealth = 1f;
    public static float wolfhealth = 1f;
    public static float maxwolfhealth = 1f;
    public static float tigerhealth = 2f;
    public static float maxtigerhealth = 2f;
    public static bool isHuman = true;
    public static bool isWolf = false;
    public static bool isTiger = false;
}
