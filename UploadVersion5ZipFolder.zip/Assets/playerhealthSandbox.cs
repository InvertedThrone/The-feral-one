using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEditor.UIElements;
using UnityEngine;

public class playerhealthSandbox : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(gameObject.layer);
        Debug.Log("is the name");
        if (gameObject.layer == 8) { Debug.Log("Human"); }
        else if (gameObject.layer == 10)
        { Debug.Log("WolfArrived"); }
        else if (gameObject.layer == 9)
        {
            Debug.Log("TigerArrived");
        }


    }

    // Update is called once per frame
    void Update()
    {

    }

    public void takeDamage(int damage)
    {
        damage = damage / 10;
        float newdamage = (float)damage;
        Debug.Log(newdamage);
        Debug.Log(" not" + damage);
        if (gameObject.layer == 8)
        {
            humandamage(damage);
            Debug.Log("H-hit");
        }
        else if (gameObject.layer == 10)
        {
            wolfdamage(damage);
            Debug.Log("Whit");
        }
        else if (gameObject.layer == 9)
        {
            tigerdamage(damage);
            Debug.Log("T-hit");
        }
    }
    void humandamage(int newdamage)
    {
        GameManager.humanhealth -= newdamage;
        if (GameManager.humanhealth <= 0)
        {
            Debug.Log("Human died");
        }
    }
    void wolfdamage(int damage)
    {
        float newdamage = (float)damage;
        GameManager.wolfhealth -= newdamage;
        if (GameManager.wolfhealth <= 0)
        {
            Debug.Log("wolf died");
        }
    }
    void tigerdamage(int damage)
    {

        GameManager.tigerhealth -= damage;
        if (GameManager.tigerhealth <= 0)
        {
            Debug.Log("tger died");
        }
    }
}
