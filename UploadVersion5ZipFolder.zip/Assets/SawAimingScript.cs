using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.PackageManager;
using UnityEngine;

public class SawAimingScript : BuzzsawScript
{
    public Transform player2;
    public Rigidbody2D rbshooter;
    public int attackRange = 1;

    public GameObject Bossobject;
    healthscript stuntracker;

    public GameObject saw;
    public GameObject triangle;
    public Transform location;
    public Transform flamelocation;
    public float timer;
    private bool cooldownsaw = false;
    private bool rangeAttack = false;

    private void Start()
    {
        player2 = GameObject.FindGameObjectWithTag("Player").transform;
        stuntracker = Bossobject.GetComponent<healthscript>();

    }


    // Update is called once per frame
    void Update()
    {
        if (stuntracker.stunned == false && stuntracker.idle == false)
        {
            player2 = GameObject.FindGameObjectWithTag("Player").transform;
            Vector3 difference = player2.transform.position - gameObject.transform.position;
            float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg - 180f;
            gameObject.transform.rotation = Quaternion.Euler(0.0f, 0.0f, rotationZ);
            Lookattarget();

            if (cooldownsaw == true)
            {
                timer += Time.deltaTime;
            }
            if (timer > 1.0f)
            {
                cooldownsaw = false;
                timer = 0;
            }
            if (cooldownsaw == false && rangeAttack == true)
            {

                Firing();
                cooldownsaw = true;

            }
            else if ( cooldownsaw == false && rangeAttack == false)
            {
                Flamethrower();
                cooldownsaw = true;
            }
            AttackOptions();
        }
    }

    public void Lookattarget()
    {
        {
            Vector3 flipped = transform.localScale;
            flipped *= -1f;
            if (transform.position.x > player2.position.x && isFlipped)
            {
                transform.localScale = flipped;
                transform.Rotate(180f, 0f, 0f);
                isFlipped = false;
            }
            else if (transform.position.x < player2.position.x && !isFlipped)
            {
                transform.localScale = flipped;
                transform.Rotate(180f, 0f, 0f);
                isFlipped = true;
            }
        }
    }


    private void Firing()
    {
        Instantiate(saw, location.position, location.rotation);
    }
    private void Flamethrower()
    {
        Instantiate(triangle, flamelocation.position, flamelocation.rotation);
    }
    private void AttackOptions()
    {
        if (Vector2.Distance(player2.position, rbshooter.position) >= attackRange)
        {
            rangeAttack = true;
        }
        else
        {
            rangeAttack = false;
        }
    }
   
}