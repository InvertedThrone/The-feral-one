using UnityEditor.Experimental.GraphView;
using UnityEditor.PackageManager;
using UnityEngine;

public class playerMovement : MonoBehaviour
{
    private float horizontal;
    private float speed = 8f;
    private float jumpingPower = 10f;
    public bool isFacingRight = true;
    private bool isGrounded = true;
    private bool Turningwolf = false;
    public GameObject wolf;
    private float transformtimer = 0f;
    public GameObject tiger;
    public GameObject Immunityframenotifier;
    public Transform abovehead;
    private bool Turningtiger = false;
    private float immunityframetimer;
    private bool immunityframes = false;
    private float playerstuntimer = 0f;
    private bool playerfreeze = false;
    private float dodgeTimer = 0f;
    private bool dodgecooldown = false;

    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField] private LayerMask enemyLayer;

    private void Start()
    {
        GameManager.isHuman = true;
        GameManager.isWolf = false;
        GameManager.isTiger = false;
    }

    void Update()
    {
        if (dodgecooldown) { dodgeTimer += Time.deltaTime; }
        if (dodgeTimer > 7f) { dodgecooldown = false; dodgeTimer = 0f; }
        if (immunityframes == true)
        {
            Instantiate(Immunityframenotifier, abovehead.transform.position, abovehead.transform.rotation);
            immunityframetimer += Time.deltaTime;
            playerfreeze = true;
            playerstuntimer += Time.deltaTime;
        }
        if (playerstuntimer > 1f)
        {
            playerfreeze = false;
            playerstuntimer = 0f;
        }
        if (immunityframetimer > 2f)
        {
            immunityframes = false;
            immunityframetimer = 0f;
        }
        horizontal = Input.GetAxisRaw("Horizontal");

            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                Debug.Log("NormalJump");
                rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
            }

            if (Input.GetButtonUp("Jump") && rb.velocity.y > 0.1f)
            {
                Debug.Log("HighJumpAttempted");
                rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.5f);
            }

            Flip();
            if (Input.GetButtonDown("Wolf") && GameManager.wolfhealth > 0f)
            {

                Instantiate(wolf, transform.position, transform.rotation);
                Turningwolf = true;
                transformtimer += Time.deltaTime;
                Debug.Log("TransformationStart");
                Destroy(gameObject);

            }
            else if (Input.GetButtonDown("Tiger") && GameManager.tigerhealth > 0f)

            {

                Instantiate(tiger, transform.position, transform.rotation);
                Turningtiger = true;
                transformtimer += Time.deltaTime;
                Debug.Log("TransformationStart");
                Destroy(gameObject);

            }
        if (Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.Z) && !dodgecooldown)
        {
            immunityframes = true;
            Debug.Log("Dodging");
            dodgecooldown = true;
        }
        if (Turningtiger || Turningwolf)
            {
                transformtimer += Time.deltaTime;
            }
            if (transformtimer > 1f)
            {

                Turningwolf = false; Turningtiger = false; transformtimer = 0f;
                Debug.Log("TransformationComplete");

            }
        

    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
 
    }

    //private bool IsGrounded()
    //{
    //    return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);
    //}

    private void Flip()
    {
        if (isFacingRight && horizontal < 0f || !isFacingRight && horizontal > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }
    private void OnTriggerExit2D(Collider2D hitInfo)
    {
        if (hitInfo.tag == "Ground" || hitInfo.tag == "Enemy")
        {
            isGrounded = false;
            Debug.Log("Left Ground");
        }
        
        
    }
    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if(hitInfo.tag == "Ground" || hitInfo.tag == "Enemy")
        {
            isGrounded = true;
            Debug.Log("TouchedGround");
        }

        else if (hitInfo.tag == "Danger1" && !immunityframes) // does more damage on the first hit
        {
            Debug.Log("hitfor10percent");
            GameManager.humanhealth -= .1f;
        }

    }
    private void OnTriggerStay2D(Collider2D hitInfo)
    {
          if (hitInfo.tag == "Danger1" && !immunityframes)
        {
            Debug.Log("hitfor10percent");
            GameManager.humanhealth -= .1f;
            immunityframes = true;
        }
        else if (hitInfo.tag == "Danger2" && !immunityframes)
        {
            GameManager.humanhealth -= .03f;
            Debug.Log("hitfor20percent");
            immunityframes = true;
        }
        else if (hitInfo.tag == "Healing")
        {
            GameManager.humanhealth = GameManager.maxhealth;
            GameManager.wolfhealth = GameManager.maxhealth;
            GameManager.tigerhealth = GameManager.maxhealth;
        }
    }
}