using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingSawScript : MonoBehaviour
{
    public float speed = 6f;
    public Rigidbody2D rb;
    public float destroytime = 10f;
    private float timer = 0f;
    public int damage = 1;



    // Start is called before the first frame update
    void Start()
    {
        rb.velocity = -transform.right * speed;
    }

    // Update is called once per frame
    void Update()
    {
        if (timer < destroytime)
        {
            timer += Time.deltaTime;
        }
        else
        {
            Debug.Log("Too far");
            Destroy(gameObject);
        }
        gameObject.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 40.0f);
    }
    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (hitInfo.tag != ("Enemy"))
        {
            if (hitInfo.tag != "Player")
            {
                Debug.Log("hit environment");
                Destroy(gameObject);
            }
            else
            {
                Debug.Log("hitplayer");
                    Destroy(gameObject);
            }
        }
    }
}
