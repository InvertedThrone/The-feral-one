using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using Unity.VisualScripting;
using UnityEngine;

public class newEnemyScript : MonoBehaviour
{
    public float speed = 30f;
    public bool idle = false;
    public bool isFlipped = false;
    Transform player;
    Rigidbody2D rb;
    public int distancefromplayer = 1;
    private float teleportTimer = 0f;
    healthscript stuntracking;

    Transform returnpoint;


    // Start is called before the first frame update
    void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();
        stuntracking = gameObject.GetComponent<healthscript>();
        Vector2 Startingpoint = new Vector2(rb.position.x, rb.position.y);
    }

    // Update is called once per frame
    void Update()
    {
        teleportTimer += Time.deltaTime;
        player = GameObject.FindGameObjectWithTag("Player").transform;
        if (stuntracking.idle == false && stuntracking.stunned == false && Vector2.Distance(player.position, rb.position) >= distancefromplayer)
        {
            
            Vector2 target = new Vector2(player.position.x, rb.position.y);
            Vector2 newpos = Vector2.MoveTowards(rb.position, target, speed * Time.fixedDeltaTime);
            rb.MovePosition(newpos);


        }
        LookatPlayer();
        if (teleportTimer > 6f)
        {
            Vector2 Gank = new Vector2(player.position.x, (player.position.y + 3));
            gameObject.transform.position = Gank;
            teleportTimer = 0;
        }
    }

    public void LookatPlayer()
    {
        Vector3 flipped = transform.localScale;
        flipped *= -1f;
        if (transform.position.x > player.position.x && isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(180f, 0f, 0f);
            isFlipped = false;
        }
        else if (transform.position.x < player.position.x && !isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(180f, 0f, 0f);
            isFlipped = true;
        }
    }

}
