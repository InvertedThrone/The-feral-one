using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TigerMovement : MonoBehaviour
{
    private float horizontal;
    private float speed = 10f;
    private float jumpingspeed = 17f;
    private float jumpingPower = 10f;
    private bool isFacingRight = true;
    private bool isGrounded = true;
    public GameObject human;
    private float transformtimer = 0f;
    private bool turninghuman;
    private bool immunityframes = false;
    private float immunityframetimer = 0f;
    private float playerstuntimer = 0f;
    private bool playerfreeze = false;
    public GameObject Immunityframenotifier;
    public Transform abovehead;
    private float dodgeTimer = 0f;
    private bool dodgecooldown = false;

    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;

    private void Start()
    {
        GameManager.isHuman = false;
        GameManager.isWolf = false;
        GameManager.isTiger = true;
    }

    void Update()
    {
        if (dodgecooldown) { dodgeTimer += Time.deltaTime; }
        if (dodgeTimer > 7f) { dodgecooldown = false; dodgeTimer = 0f; }
            
        
        if (immunityframes == true)
        {
            Instantiate(Immunityframenotifier, abovehead.transform.position, abovehead.transform.rotation);
            immunityframetimer += Time.deltaTime;
            playerfreeze = true;
            playerstuntimer += Time.deltaTime;
        }
        if (playerstuntimer > 1f)
        {
            playerfreeze = false;
            playerstuntimer = 0f;
        }
        if (immunityframetimer > 2f)
        {
            immunityframes = false;
            immunityframetimer = 0f;
        }

        horizontal = Input.GetAxisRaw("Horizontal");

            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                Debug.Log("NormalJump");
                rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
            }

            if (Input.GetButtonUp("Jump") && rb.velocity.y > 0.0f)
            {
                Debug.Log("HighJumpAttempted");
                rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * .9f);
            }

            Flip();
            if (Input.GetButtonDown("Human"))
            {

                turnHuman();

            }
         if (Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.Z) && !dodgecooldown)
        {
            immunityframes = true;
            Debug.Log("Dodging");
            dodgecooldown = true;
        }
         

        if (transformtimer > 1f)
        {
            turninghuman = false;
            transformtimer = 0f;
            Debug.Log("Tigerappear");

        }
        if( GameManager.tigerhealth < 0f)
        {
            turnHuman();
        }

    }

    private void FixedUpdate()
    {
        if (isGrounded = true)
        {
            rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
        }
        else
        {
            rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
        }
    }

 

    private void Flip()
    {
        if (isFacingRight && horizontal < 0f || !isFacingRight && horizontal > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }
    private void turnHuman()
    {
        Instantiate(human, transform.position, transform.rotation);
        turninghuman = true;
        transformtimer += Time.deltaTime;
        Debug.Log("TransformationStart");
        Destroy(gameObject);
    }
    private void OnTriggerExit2D(Collider2D hitInfo)
    {
        if (hitInfo.tag == "Ground" || hitInfo.tag == "Enemy")
        {
            isGrounded = false;
            Debug.Log("LeftGround");
        }
        
    }
    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (hitInfo.tag == "Ground" || hitInfo.tag == "Enemy")
        {
            isGrounded = true;
            Debug.Log("TouchedGround");
        }


        else if (hitInfo.tag == "Danger1" && !immunityframes)
        {
            Debug.Log("hitfor10percent");
            GameManager.tigerhealth -= .1f;
        }
    }
    private void OnTriggerStay2D(Collider2D hitInfo)
    {

         if (hitInfo.tag == "Danger2" && !immunityframes)
        {
            GameManager.tigerhealth -= .03f;
            Debug.Log("hitfor20percent");
            immunityframes = true;
        }
        else if (hitInfo.tag == "Healing")
        {
            GameManager.humanhealth = GameManager.maxhealth;
            GameManager.wolfhealth = GameManager.maxhealth;
            GameManager.tigerhealth = GameManager.maxhealth;
        }
    }
}
