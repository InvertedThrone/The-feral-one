using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackScript : MonoBehaviour
{

    public GameObject LightAttack1;
    public GameObject LightAttack2;
    public GameObject LightAttack3;
    public Transform AttackLocation;
    public Transform AttackLocation2;
    public Transform AttackLocation3;
    public bool windup = false;
    private float DelayTimer = 0f;
    public bool recovery = false;
    private float DelayTimer2 = 0f;
    public int damage = 10;
    public int posture = 25;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1") && windup == false && recovery == false)
        {
            Shoot();
            recovery = true;
        }
        else if (Input.GetButtonDown("Fire2") && windup == false && recovery == false)
            {
                Shoot3();
            recovery = true;
            }
        else if (Input.GetButtonDown("Submit"))
        {
            Debug.Log("Heavyhit");
            
            windup = true;
        }
        if ( windup == true)
        {
            DelayTimer += Time.deltaTime;
        }
        if (DelayTimer > 1f)
        {
            Shoot2();
            windup = false;
            DelayTimer = 0f;
            recovery = true;
        }
        if (recovery == true)
        {
            DelayTimer2 += Time.deltaTime;
        }
        if (DelayTimer2 > 1f)
        {

            recovery = false;
            DelayTimer2 = 0f;
        }

    }

    void Shoot()
    {
        Instantiate(LightAttack1, AttackLocation.position, AttackLocation.rotation);
    }

    void Shoot2()
    {
        Instantiate(LightAttack2, AttackLocation2.position, AttackLocation2.rotation);
    }
    void Shoot3()
    {
        Instantiate(LightAttack3, AttackLocation3.position, AttackLocation3.rotation);
    }

}
