using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class OffenseScript : MonoBehaviour
{
    public Transform playerChar;
    public int damage = 10;
    public int posturedamage = 25;
    private float Timer = 0f;
    public float Attackrange = .3f;
    public LayerMask Enemylayers;
    AttackScript damagenumbers;
    // Start is called before the first frame update
    void Start()
    {
        playerChar = GameObject.FindGameObjectWithTag("Player").transform;

    }

    // Update is called once per frame
    void Update()
    {
        
        Timer += Time.deltaTime;

        Explode();

        Collider2D[] hitenemies = Physics2D.OverlapCircleAll(transform.position, Attackrange, Enemylayers);

        foreach(Collider2D currentEnemy in hitenemies)
        {
            Debug.Log("we hit" + currentEnemy.name);
            healthscript enemytarget = currentEnemy.GetComponent<healthscript>();
            if(enemytarget != null)
            {
                enemytarget.takedamage(damage);
                enemytarget.takeposture(posturedamage);
                Debug.Log("Targethit");
                Destroy(gameObject);
            }

        }
    }

    private void Explode()
    {
        if (Timer > 3f)
        {
            Timer = 0f;
            Destroy(gameObject);
        }
    }

    public void OnTriggerEnter2D(Collider2D hitInfo)
    {
        if (hitInfo.tag != "Enemy")
        {
            Destroy(gameObject);
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, Attackrange);
    }
    //private void OnTriggerEnter2D(Collider2D hitInfo)
    //{
    //    if (hitInfo.tag != "Enemy")
    //    {


    //        Debug.Log(hitInfo.name);
    //        healthscript Enemy = hitInfo.GetComponent<healthscript>();
    //        if (Enemy != null)
    //        {
    //            Enemy.takedamage(damage);
    //            Debug.Log("Enemy takes" + damage);
    //            Enemy.takeposture(posturedamage);
    //            Destroy(gameObject);
    //        }
    //        if (Enemy != null)
    //        {
    //            Destroy(gameObject);
    //        }
    //    }
    //}
}
