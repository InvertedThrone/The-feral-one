using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ArrowScript : MonoBehaviour
{
    public Transform playerChar;
    private int damage = 10;
    private int posturedamage = 25;
    private float Timer = 0f;
    private float Attackrange = .3f;
    private float speed = 6f;
    public LayerMask Enemylayers;
    AttackScript damagenumbers;
    public Rigidbody2D rb;
    playerMovement positiontracking;
    // Start is called before the first frame update
    void Start()
    {
       
        playerChar = GameObject.FindGameObjectWithTag("Player").transform;
        rb.velocity = -transform.right * speed;
        positiontracking = playerChar.GetComponent<playerMovement>();
        if(positiontracking.isFacingRight == true)
        {
            rb.velocity = transform.right * speed;
        }
        else
        {
            rb.velocity = -transform.right * speed;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Timer <= 10f)
        {
            Timer += Time.deltaTime;

            Tofar();
        }
        Collider2D[] hitenemies = Physics2D.OverlapCircleAll(transform.position, Attackrange, Enemylayers);

        foreach (Collider2D currentEnemy in hitenemies)
        {
            Debug.Log("we hit" + currentEnemy.name);
            healthscript enemytarget = currentEnemy.GetComponent<healthscript>();
            if (enemytarget != null)
            {
                enemytarget.takedamage(damage);
                enemytarget.takeposture(posturedamage);
                Debug.Log("Targethit");
                Destroy(gameObject);
            }

        }
    }

    private void Tofar()
    {
        if (Timer > 10f)
        {
            Timer = 0f;
            Destroy(gameObject);
        }
    }

    //private void OnTriggerEnter2D(Collider2D hitInfo)
    //{
    //    if (hitInfo.tag != "Enemy" || hitInfo.tag != "Human")
    //    {
    //        Destroy(gameObject);
    //    }
    //}

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, Attackrange);
    }
}